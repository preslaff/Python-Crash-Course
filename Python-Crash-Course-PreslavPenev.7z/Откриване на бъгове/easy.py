# Оправете грешката

first_name = "John"
last_name = "Doe"
full_name = first_name + " " + last_name
print(full_name)
